import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DoProductFilterComponent } from './do-product-filter.component';

describe('DoProductFilterComponent', () => {
  let component: DoProductFilterComponent;
  let fixture: ComponentFixture<DoProductFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DoProductFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DoProductFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
