import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-do-product-filter',
  templateUrl: './do-product-filter.component.html',
  styleUrls: ['./do-product-filter.component.css']
})
export class DoProductFilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
